#pragma once

bool isCorrect(const char* expression);